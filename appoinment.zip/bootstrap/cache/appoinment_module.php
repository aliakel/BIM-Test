<?php return array (
  'providers' => 
  array (
    0 => 'BeInMedia\\Appoinment\\Providers\\AppoinmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'BeInMedia\\Appoinment\\Providers\\AppoinmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);