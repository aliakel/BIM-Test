<?php return array (
  'providers' => 
  array (
    0 => 'BeInMedia\\User\\Providers\\UserServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'BeInMedia\\User\\Providers\\UserServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);