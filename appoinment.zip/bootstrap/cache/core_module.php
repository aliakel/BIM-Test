<?php return array (
  'providers' => 
  array (
    0 => 'BeInMedia\\Core\\Providers\\CoreServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'BeInMedia\\Core\\Providers\\CoreServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);