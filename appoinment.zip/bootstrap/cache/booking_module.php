<?php return array (
  'providers' => 
  array (
    0 => 'BeInMedia\\Booking\\Providers\\BookingServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'BeInMedia\\Booking\\Providers\\BookingServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);