export default {
    data: {
        loading:false,
        lang:window.lang,
    }
}
